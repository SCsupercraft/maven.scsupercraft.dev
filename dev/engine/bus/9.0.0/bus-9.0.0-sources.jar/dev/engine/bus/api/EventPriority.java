/*
 * Minecraft Forge
 * Copyright (c) 2016.
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

package dev.engine.bus.api;

/**
 * Different priorities for {@link Event} listeners.
 * <p>
 * The default level for a listener registered
 * without a priority is {@link #NORMAL}.
 *
 * @see SubscribeEvent#priority()
 */
public enum EventPriority {
    // Note:
    // Due to using a ArrayList in the ListenerList,
    // these need to stay in a contiguous index starting at 0. {Default ordinal}

    /**
     * The highest priority, and the first to execute.
     */
    HIGHEST,
    /**
     * The second-highest priority, executes after {@link #HIGHEST} and before {@link #NORMAL}.
     */
    HIGH,
    /**
     * The default level for a listener registered without a priority.
     */
    NORMAL,
    /**
     * The second-lowest priority, executes after {@link #NORMAL} and before {@link #LOWEST}.
     */
    LOW,
    /**
     * The lowest priority, and the last to execute.
     */
    LOWEST
}
